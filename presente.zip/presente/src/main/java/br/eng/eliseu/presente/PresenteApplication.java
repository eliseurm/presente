package br.eng.eliseu.presente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PresenteApplication {

	public static void main(String[] args) {
		SpringApplication.run(PresenteApplication.class, args);
	}

}
