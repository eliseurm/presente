package br.eng.eliseu.presente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PresenteApplicationTests {

	@Test
	void contextLoads() {
	}

}
